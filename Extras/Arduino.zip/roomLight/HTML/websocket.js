// Config
var port = 9000;
var host = "ws://127.0.0.1:"+port;

var socket;
var valueReceived = 0

function init() {
	try {
		socket = new WebSocket(host);
		console.log('WebSocket status '+socket.readyState);
		socket.onopen = function(msg) {
								console.log("Welcome - status "+this.readyState);
							 };
		socket.onmessage = function(msg) {
							   console.log("Message Received: "+msg.data);
							   valueReceived = parseInt(msg.data);
								 drawChart();
						   };
		socket.onclose   = function(msg) {
							   console.log("Disconnected - status "+this.readyState);
						   };
	}
	catch(ex){
		console.log(ex);
	}

}

function quit(){
	if (socket != null) {
		console.log("Close Socket");
		socket.close();
		socket=null;
	}
}

function reconnect() {
	quit();
	init();
}
