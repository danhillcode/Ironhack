google.charts.load('current', {'packages':['gauge']});
google.charts.setOnLoadCallback(drawChart);
function drawChart() {

var data = google.visualization.arrayToDataTable([
	['Label', 'Value'],
	['Light', valueReceived],
]);

var options = {
	width: 400, height: 240,
	yellowFrom:900, yellowTo: 990,
	redFrom:990, redTo: 1010,
	minorTicks: 2,
	min: 950,
	max: 1030
};

var chart = new google.visualization.Gauge(document.getElementById('chart_div'));

chart.draw(data, options);

setInterval(function() {
	data.setValue(0, 1, valueReceived);
	chart.draw(data, options);
}, 1000);
}
