require 'eventmachine'
require 'em-websocket'
require 'socket'

EM.run {
  EM::WebSocket.run(:host => "0.0.0.0", :port => 9000) do |ws|

    ws.onopen { |handshake|
      puts "WebSocket connection open"
      #ws.send "Hello Client, you connected to: #{Socket.gethostname}. websocket server path: #{handshake.path}"


    timer = EventMachine::PeriodicTimer.new(1) do

      ws.send "A"


    end
    }

    ws.onclose { puts "Connection closed" }

  end
}
