require 'eventmachine'
require 'em-websocket'
require "serialport"
require 'socket'

port_str = "/dev/cu.usbserial-A9007Kef"
baud_rate = 9600
data_bits = 8
stop_bits = 1
parity = SerialPort::NONE

sp = SerialPort.new(port_str, baud_rate, data_bits, stop_bits, parity)


EM.run {
  EM::WebSocket.run(:host => "0.0.0.0", :port => 9000) do |ws|

    ws.onopen { |handshake|
      puts "WebSocket connection open"

      timer = EventMachine::PeriodicTimer.new(0.025) do
        last_msg_sp = sp.gets.chomp
        ws.send last_msg_sp
      end
    }

    ws.onclose { puts "Connection closed" }

  end
}
